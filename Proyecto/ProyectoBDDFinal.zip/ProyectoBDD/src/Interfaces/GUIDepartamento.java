package Interfaces;


import Conexion.Conexion;
import Conexion.Operaciones;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



public class GUIDepartamento extends javax.swing.JFrame {
    DefaultTableModel datosModel=new DefaultTableModel();
    private ImageIcon imagen;
    private Icon icono;
    public GUIDepartamento() {
        initComponents();
        this.imagenSet(this.lblPaciente, "src/Icons/Departamento.png");
        
    }
    
    
    
     public void limpiar(){
        txtCodDep.setText("");
        txtCodHos.setText("");
        txtNombre.setText("");
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel10 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        btnModificarp = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txtCodHos = new javax.swing.JTextField();
        lblResultado = new javax.swing.JLabel();
        lblPaciente = new javax.swing.JLabel();
        btnRegresar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        datos = new javax.swing.JTable();
        btnAddp1 = new javax.swing.JButton();
        btnElminarp = new javax.swing.JButton();
        btnBuscarp2 = new javax.swing.JButton();
        btnBuscarp3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtCodDep = new javax.swing.JTextField();
        btnBuscarpacientes = new javax.swing.JButton();

        jLabel10.setText("Código médico:");

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Departamento");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setText("Departamentos");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 90, 380, -1));

        jLabel8.setText("Código Departamento");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 200, 120, -1));

        txtNombre.setBackground(new java.awt.Color(242, 242, 242));
        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        jPanel1.add(txtNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 230, 210, -1));

        btnModificarp.setBackground(new java.awt.Color(242, 242, 242));
        btnModificarp.setText("Modificar Departamento");
        btnModificarp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarpActionPerformed(evt);
            }
        });
        jPanel1.add(btnModificarp, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 480, 160, -1));

        jLabel9.setText("Código Hospital");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 120, -1));

        txtCodHos.setBackground(new java.awt.Color(242, 242, 242));
        txtCodHos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodHosActionPerformed(evt);
            }
        });
        jPanel1.add(txtCodHos, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 260, 210, -1));
        jPanel1.add(lblResultado, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));
        jPanel1.add(lblPaciente, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 110, 80));

        btnRegresar.setBackground(new java.awt.Color(242, 242, 242));
        btnRegresar.setText("Regresar al Menú");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 160, -1));

        datos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(datos);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 20, 800, -1));

        btnAddp1.setBackground(new java.awt.Color(242, 242, 242));
        btnAddp1.setText("Agregar Departamento");
        btnAddp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddp1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnAddp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 480, 160, -1));

        btnElminarp.setBackground(new java.awt.Color(242, 242, 242));
        btnElminarp.setText("Eliminar Departamento");
        btnElminarp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnElminarpActionPerformed(evt);
            }
        });
        jPanel1.add(btnElminarp, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 480, 160, -1));

        btnBuscarp2.setBackground(new java.awt.Color(242, 242, 242));
        btnBuscarp2.setText("Consultar Departamento");
        btnBuscarp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarp2ActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscarp2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 480, 160, -1));

        btnBuscarp3.setBackground(new java.awt.Color(242, 242, 242));
        btnBuscarp3.setText("Consultar Paciente");
        btnBuscarp3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarp3ActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscarp3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 480, 160, -1));

        jLabel2.setText("Nombre");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, 100, -1));

        txtCodDep.setBackground(new java.awt.Color(242, 242, 242));
        txtCodDep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodDepActionPerformed(evt);
            }
        });
        jPanel1.add(txtCodDep, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 200, 210, -1));

        btnBuscarpacientes.setBackground(new java.awt.Color(242, 242, 242));
        btnBuscarpacientes.setText("Consultar todos los departamento");
        btnBuscarpacientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarpacientesActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscarpacientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 480, 190, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1259, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 559, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtCodHosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodHosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodHosActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
       GUIMain menu = new GUIMain();
       menu.setVisible(true);
       this.setVisible(false);
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnModificarpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarpActionPerformed
        String codH=txtCodHos.getText();
        String codD=txtCodDep.getText();
        String nombre=txtNombre.getText();
        
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        
        //arreglos de parametros a pasar al metodo de operaciones
        
        //arreglos de parametros a pasar al metodo de operaciones
        String[][] valuesDepartamento = new String[3][3];
        String clave[] = new String[4];
        String tablaDepartamento = "departamento";
        
        //Valores para el paciente
        valuesDepartamento[0][0] = codD;
        valuesDepartamento[0][1] = nombre;
        valuesDepartamento[0][2] = codH;
        //Nombres de columnas 
        valuesDepartamento[1][0] = "cod_departamento";
        valuesDepartamento[1][1] = "nombre";
        valuesDepartamento[1][2] = "cod_hospital";
        //valores del tipo de datos 
        valuesDepartamento[2][0] = "Integer";
        valuesDepartamento[2][1] = "String";
        valuesDepartamento[2][2] = "String";
       //arreglo para la clave y parametro
        clave[0]=codD;
        clave[1]="cod_departamento";
        clave[2]="String";
        op.Update(conectar, tablaDepartamento, valuesDepartamento,clave);
    }//GEN-LAST:event_btnModificarpActionPerformed

    private void btnAddp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddp1ActionPerformed
        String codH=txtCodHos.getText();
        String codD=txtCodDep.getText();
        String nombre=txtNombre.getText();
        
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        
        //arreglos de parametros a pasar al metodo de operaciones
        
        //arreglos de parametros a pasar al metodo de operaciones
        String[][] valuesDepartamento = new String[3][3];
        String clave[] = new String[4];
        String tablaDepartamento = "departamento";
        
        //Valores para el paciente
        valuesDepartamento[0][0] = codD;
        valuesDepartamento[0][1] = nombre;
        valuesDepartamento[0][2] = codH;
        //Nombres de columnas 
        valuesDepartamento[1][0] = "cod_departamento";
        valuesDepartamento[1][1] = "nombre";
        valuesDepartamento[1][2] = "cod_hospital";
        //valores del tipo de datos 
        valuesDepartamento[2][0] = "Integer";
        valuesDepartamento[2][1] = "String";
        valuesDepartamento[2][2] = "String";
       //arreglo para la clave y parametro
        clave[0]=codD;
        clave[1]="cod_departamento";
        clave[2]="String";
        op.Create(conectar, tablaDepartamento, valuesDepartamento);
        try {
            conectar.close();
        } catch (SQLException ex) {
            Logger.getLogger(GUIPaciente.class.getName()).log(Level.SEVERE, null, ex);
        }
   
        limpiar();
    }//GEN-LAST:event_btnAddp1ActionPerformed

    private void btnElminarpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnElminarpActionPerformed
        String codD=txtCodDep.getText();
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String tabla = "departamento";
        String clave[]=new String[3];
        clave[0]=txtCodDep.getText();
        clave[1]="cod_departamento";
        clave[2]="String";
        op.Delete(conectar, tabla, clave);
    }//GEN-LAST:event_btnElminarpActionPerformed

    private void btnBuscarp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarp2ActionPerformed
        String codD=txtCodDep.getText();
    
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
       
            String tabla = "departamento";
            codD="cod_departamento="+codD;
            datosModel = op.ReadWhere(conectar, tabla, codD);
            this.datos.setModel(datosModel);
            try {
                conectar.close();
            } catch (SQLException ex) {
                Logger.getLogger(GUIDepartamento.class.getName()).log(Level.SEVERE, null, ex);
            }
            
    }//GEN-LAST:event_btnBuscarp2ActionPerformed

    private void btnBuscarp3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarp3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBuscarp3ActionPerformed

    private void txtCodDepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodDepActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodDepActionPerformed

    private void btnBuscarpacientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarpacientesActionPerformed
        String codD=txtCodDep.getText();
    
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
       
            String tabla = "departamento";
            codD="cod_departamento="+codD;
            datosModel = op.Read(conectar, tabla);
            this.datos.setModel(datosModel);
            try {
                conectar.close();
            } catch (SQLException ex) {
                Logger.getLogger(GUIDepartamento.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_btnBuscarpacientesActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUIMain().setVisible(true);
            }
        });
    }
    private void imagenSet(JLabel lbl, String ruta){
        this.imagen=new ImageIcon(ruta);
        this.icono =new ImageIcon(this.imagen.getImage().getScaledInstance(lbl.getWidth(), lbl.getHeight(), Image.SCALE_DEFAULT));
        lbl.setIcon(this.icono);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddp1;
    private javax.swing.JButton btnBuscarp2;
    private javax.swing.JButton btnBuscarp3;
    private javax.swing.JButton btnBuscarpacientes;
    private javax.swing.JButton btnElminarp;
    private javax.swing.JButton btnModificarp;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JTable datos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JLabel lblPaciente;
    private javax.swing.JLabel lblResultado;
    private javax.swing.JTextField txtCodDep;
    private javax.swing.JTextField txtCodHos;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
