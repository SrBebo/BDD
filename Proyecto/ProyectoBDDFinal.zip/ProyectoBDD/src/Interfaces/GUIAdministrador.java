package Interfaces;

import Conexion.Operaciones;
import java.awt.Image;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableModel;


public class GUIAdministrador extends javax.swing.JFrame {

    DefaultTableModel datosModel=new DefaultTableModel();
    private ImageIcon imagen;
    private Icon icono;
    public GUIAdministrador() {
        initComponents();
        this.imagenSet(this.lblPersonalA, "src/Icons/Admin.jpg");
    }

    public void limpiar(){
        txtCodD.setText("");
        txtRol.setText("");
        txtSalario.setText("");
        txtCedula.setText("");
        txtCodH.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnConsulatarTPA = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        datos = new javax.swing.JTable();
        btnConsultarPA = new javax.swing.JButton();
        btnRegresar1 = new javax.swing.JButton();
        btnAgregarPA = new javax.swing.JButton();
        txtCodD = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtSalario = new javax.swing.JTextField();
        txtRol = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtCedula = new javax.swing.JTextField();
        btnModificarPA = new javax.swing.JButton();
        btnElminarPA = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtCodH = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtNombres = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        lblPersonalA = new javax.swing.JLabel();
        lblMostrar = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Consultar Personal Administrativo");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setText("Personal Administrativo");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 10, 550, -1));

        btnConsulatarTPA.setBackground(new java.awt.Color(204, 204, 204));
        btnConsulatarTPA.setText("Consultar todo el Personal Administrativo");
        btnConsulatarTPA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsulatarTPAActionPerformed(evt);
            }
        });
        jPanel1.add(btnConsulatarTPA, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 380, 250, -1));

        datos.setBackground(new java.awt.Color(242, 242, 242));
        datos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(datos);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 90, 840, 240));

        btnConsultarPA.setBackground(new java.awt.Color(204, 204, 204));
        btnConsultarPA.setText("Consultar Personal Administrativo");
        btnConsultarPA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultarPAActionPerformed(evt);
            }
        });
        jPanel1.add(btnConsultarPA, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 380, 210, -1));

        btnRegresar1.setBackground(new java.awt.Color(242, 242, 242));
        btnRegresar1.setText("Regresar al Menú");
        btnRegresar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegresar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, 160, -1));

        btnAgregarPA.setBackground(new java.awt.Color(242, 242, 242));
        btnAgregarPA.setText("Agregar Personal Administrativo");
        btnAgregarPA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarPAActionPerformed(evt);
            }
        });
        jPanel1.add(btnAgregarPA, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 380, 210, -1));

        txtCodD.setBackground(new java.awt.Color(242, 242, 242));
        txtCodD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodDActionPerformed(evt);
            }
        });
        jPanel1.add(txtCodD, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 290, 210, -1));

        jLabel12.setText("Código Departamento:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, 120, -1));

        jLabel11.setText("Salario:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 120, -1));

        txtSalario.setBackground(new java.awt.Color(242, 242, 242));
        txtSalario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalarioActionPerformed(evt);
            }
        });
        jPanel1.add(txtSalario, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, 210, -1));

        txtRol.setBackground(new java.awt.Color(242, 242, 242));
        txtRol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRolActionPerformed(evt);
            }
        });
        jPanel1.add(txtRol, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 230, 210, -1));

        jLabel9.setText("Rol:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 120, -1));

        jLabel10.setText("Cédula:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 120, -1));

        txtCedula.setBackground(new java.awt.Color(242, 242, 242));
        txtCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCedulaActionPerformed(evt);
            }
        });
        jPanel1.add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, 210, -1));

        btnModificarPA.setBackground(new java.awt.Color(242, 242, 242));
        btnModificarPA.setText("Modificar Personal Administrativo");
        btnModificarPA.setToolTipText("");
        btnModificarPA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarPAActionPerformed(evt);
            }
        });
        jPanel1.add(btnModificarPA, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 380, 160, -1));

        btnElminarPA.setBackground(new java.awt.Color(242, 242, 242));
        btnElminarPA.setText("Eliminar Personal Administrativo");
        btnElminarPA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnElminarPAActionPerformed(evt);
            }
        });
        jPanel1.add(btnElminarPA, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 380, 160, -1));

        jLabel2.setText("Código Hospital:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 100, -1));

        txtCodH.setBackground(new java.awt.Color(242, 242, 242));
        txtCodH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodHActionPerformed(evt);
            }
        });
        jPanel1.add(txtCodH, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 200, 210, -1));

        jLabel13.setText("Nombres:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 120, -1));

        jLabel14.setText("Apellidos:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, 120, -1));

        txtNombres.setBackground(new java.awt.Color(242, 242, 242));
        txtNombres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombresActionPerformed(evt);
            }
        });
        jPanel1.add(txtNombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 140, 210, -1));

        txtApellidos.setBackground(new java.awt.Color(242, 242, 242));
        txtApellidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidosActionPerformed(evt);
            }
        });
        jPanel1.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 170, 210, -1));
        jPanel1.add(lblPersonalA, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 110, 80));
        jPanel1.add(lblMostrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 420, 340, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1313, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 493, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnConsulatarTPAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsulatarTPAActionPerformed
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String tabla1 = "persona";
        String tabla2 = "personal_administrativo";
        String[][] columnas = new String[7][2];
        columnas[0][0] = "cedula"; columnas[0][1] = "persona";
        columnas[1][0] = "nombres"; columnas[1][1] = "persona";
        columnas[2][0] = "apellidos"; columnas[2][1] = "persona";
        columnas[3][0] = "rol"; columnas[3][1] = "objeto";
        columnas[4][0] = "salario"; columnas[4][1] = "objeto";
        columnas[5][0] = "cod_departamento"; columnas[5][1] = "objeto";
        columnas[6][0] = "cod_hospital"; columnas[6][1] = "objeto";
        String condicion = columnas[0][0]; 
        
        //datosModel = op.Read(conectar, tabla);
        datosModel  = op.ReadTwoTables(conectar, tabla1, tabla2, columnas, condicion);
        this.datos.setModel(datosModel);
        try {
            conectar.close();
        } catch (SQLException ex) {
            Logger.getLogger(GUIPaciente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnConsulatarTPAActionPerformed

    private void btnRegresar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar1ActionPerformed
        GUIMain menu = new GUIMain();
        menu.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnRegresar1ActionPerformed

    private void btnAgregarPAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarPAActionPerformed
        String cedula=txtCedula.getText();
        String rol=txtRol.getText();
        String salario=txtSalario.getText();
        String codDepar=txtCodD.getText();
        String codHos=txtCodH.getText();
        String nombre=txtNombres.getText();
        String apellido=txtApellidos.getText();

        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        
        //arreglos de parametros a pasar al metodo de operaciones
        String valuesAdmin[][] = new String[3][5];
        String valuesPersona[][] = new String[3][4];
        String clave[] = new String[4];
        String tablaPersona = "persona";
        String tablaAdmin = "personal_administrativo";
        
        //Valores para el paciente
        valuesPersona[0][0] = cedula;
        valuesPersona[0][1] = nombre;
        valuesPersona[0][2] = apellido;
        valuesPersona[0][3] = codHos;
        //Nombres de columnas 
        valuesPersona[1][0] = "cedula";
        valuesPersona[1][1] = "nombres";
        valuesPersona[1][2] = "apellidos";
        valuesPersona[1][3] = "cod_hospital";
        //valores del tipo de datos 
        valuesPersona[2][0] = "String";
        valuesPersona[2][1] = "String";
        valuesPersona[2][2] = "String";
        valuesPersona[2][3] = "String";
        
        //Valores para el Admin
        valuesAdmin[0][0] = cedula;
        valuesAdmin[0][1] = codHos;
        valuesAdmin[0][2] = rol;
        valuesAdmin[0][3] = salario;
        valuesAdmin[0][4] = codDepar;
        //Nombres de columnas 
        valuesAdmin[1][0] = "cedula";
        valuesAdmin[1][1] = "cod_hospital"; 
        valuesAdmin[1][2] = "rol";
        valuesAdmin[1][3] = "salario";
        valuesAdmin[1][4] = "cod_departamento";
        //valores del tipo de datos 
        valuesAdmin[2][0] = "String";
        valuesAdmin[2][1] = "String";
        valuesAdmin[2][2] = "String";
        valuesAdmin[2][3] = "Integer";
        valuesAdmin[2][4] = "Integer";
       //arreglo para la clave y parametro
        clave[0]=cedula;
        clave[1]="cedula";
        clave[2]="String";
        
        op.Create(conectar, tablaPersona, valuesPersona);
        op.Create(conectar, tablaAdmin, valuesAdmin);
        
        try {
            conectar.close();
        } catch (SQLException ex) {
            Logger.getLogger(GUIPaciente.class.getName()).log(Level.SEVERE, null, ex);
        }
   
        limpiar();
    }//GEN-LAST:event_btnAgregarPAActionPerformed

    private void txtCodDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodDActionPerformed

    private void txtSalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSalarioActionPerformed

    private void txtRolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRolActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRolActionPerformed

    private void txtCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCedulaActionPerformed

    private void btnConsultarPAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarPAActionPerformed
        String cedula=txtCedula.getText();
        
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String tabla1 = "persona";
        String tabla2 = "personal_administrativo";
        String[][] columnas = new String[7][2];
        columnas[0][0] = "cedula"; columnas[0][1] = "persona";
        columnas[1][0] = "nombres"; columnas[1][1] = "persona";
        columnas[2][0] = "apellidos"; columnas[2][1] = "persona";
        columnas[3][0] = "rol"; columnas[3][1] = "objeto";
        columnas[4][0] = "salario"; columnas[4][1] = "objeto";
        columnas[5][0] = "cod_departamento"; columnas[5][1] = "objeto";
        columnas[6][0] = "cod_hospital"; columnas[6][1] = "objeto";
        String condicion = columnas[0][0]; 
        
        //datosModel = op.Read(conectar, tabla);
        datosModel  = op.ReadTwoTablesWhere(conectar, tabla1, tabla2, columnas, condicion,cedula);
        this.datos.setModel(datosModel);
            try {
                conectar.close();
            } catch (SQLException ex) {
                Logger.getLogger(GUIPaciente.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_btnConsultarPAActionPerformed

    private void btnModificarPAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarPAActionPerformed
        String cedula=txtCedula.getText();
        String rol=txtRol.getText();
        String salario=txtSalario.getText();
        String codDepar=txtCodD.getText();
        String codHos=txtCodH.getText();
        String nombre=txtNombres.getText();
        String apellido=txtApellidos.getText();

        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        
        //arreglos de parametros a pasar al metodo de operaciones
        String valuesAdmin[][] = new String[3][5];
        String valuesPersona[][] = new String[3][4];
        String clave[] = new String[4];
        String tablaPersona = "persona";
        String tablaAdmin = "personal_administrativo";
        
        //Valores para el paciente
        valuesPersona[0][0] = cedula;
        valuesPersona[0][1] = nombre;
        valuesPersona[0][2] = apellido;
        valuesPersona[0][3] = codHos;
        //Nombres de columnas 
        valuesPersona[1][0] = "cedula";
        valuesPersona[1][1] = "nombres";
        valuesPersona[1][2] = "apellidos";
        valuesPersona[1][3] = "cod_hospital";
        //valores del tipo de datos 
        valuesPersona[2][0] = "String";
        valuesPersona[2][1] = "String";
        valuesPersona[2][2] = "String";
        valuesPersona[2][3] = "String";
        
        //Valores para el Admin
        valuesAdmin[0][0] = cedula;
        valuesAdmin[0][1] = codHos;
        valuesAdmin[0][2] = rol;
        valuesAdmin[0][3] = salario;
        valuesAdmin[0][4] = codDepar;
        //Nombres de columnas 
        valuesAdmin[1][0] = "cedula";
        valuesAdmin[1][1] = "cod_hospital"; 
        valuesAdmin[1][2] = "rol";
        valuesAdmin[1][3] = "salario";
        valuesAdmin[1][4] = "cod_departamento";
        //valores del tipo de datos 
        valuesAdmin[2][0] = "String";
        valuesAdmin[2][1] = "String";
        valuesAdmin[2][2] = "String";
        valuesAdmin[2][3] = "Integer";
        valuesAdmin[2][4] = "Integer";
       //arreglo para la clave y parametro
        clave[0]=cedula;
        clave[1]="cedula";
        clave[2]="String";
        
        op.Update(conectar, tablaPersona, valuesPersona,clave);
        op.Update(conectar, tablaAdmin, valuesAdmin,clave);

    }//GEN-LAST:event_btnModificarPAActionPerformed

    private void btnElminarPAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnElminarPAActionPerformed
        String cedula=txtCedula.getText();
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String tabla2 = "paciente";
        String tabla = "personal_administrativo";
        String clave[]=new String[3];
        clave[0]=txtCedula.getText();
        clave[1]="cedula";
        clave[2]="String";
        op.Delete(conectar, tabla2, clave);
        op.Delete(conectar, tabla, clave);
    }//GEN-LAST:event_btnElminarPAActionPerformed

    private void txtCodHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodHActionPerformed

    private void txtNombresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombresActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombresActionPerformed

    private void txtApellidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidosActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUIMain().setVisible(true);
            }
        });
    }
    
    private void imagenSet(JLabel lbl, String ruta){
        this.imagen=new ImageIcon(ruta);
        this.icono =new ImageIcon(this.imagen.getImage().getScaledInstance(lbl.getWidth(), lbl.getHeight(), Image.SCALE_REPLICATE));
        lbl.setIcon(this.icono);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarPA;
    private javax.swing.JButton btnConsulatarTPA;
    private javax.swing.JButton btnConsultarPA;
    private javax.swing.JButton btnElminarPA;
    private javax.swing.JButton btnModificarPA;
    private javax.swing.JButton btnRegresar1;
    private javax.swing.JTable datos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblMostrar;
    private javax.swing.JLabel lblPersonalA;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtCodD;
    private javax.swing.JTextField txtCodH;
    private javax.swing.JTextField txtNombres;
    private javax.swing.JTextField txtRol;
    private javax.swing.JTextField txtSalario;
    // End of variables declaration//GEN-END:variables
}
