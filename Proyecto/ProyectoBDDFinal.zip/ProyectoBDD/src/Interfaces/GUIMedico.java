package Interfaces;


import Conexion.Conexion;
import Conexion.Operaciones;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



public class GUIMedico extends javax.swing.JFrame {
    DefaultTableModel datosModel=new DefaultTableModel();
    private ImageIcon imagen;
    private Icon icono;
    public GUIMedico() {
        initComponents();
        this.imagenSet(this.lblPaciente, "src/Icons/Paciente.jpg");
        
    }
    
    
    
    public void limpiar(){
        txtCedula.setText("");
        txtCodH.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        txtEspecialidad.setText("");
        txtCodDep.setText("");
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel10 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtCodH = new javax.swing.JTextField();
        btnModificarm = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txtNombres = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtApellidos = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtCodDep = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        lblResultado = new javax.swing.JLabel();
        lblPaciente = new javax.swing.JLabel();
        btnRegresar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        datos = new javax.swing.JTable();
        btnAddm1 = new javax.swing.JButton();
        btnElminarm = new javax.swing.JButton();
        btnBuscarm2 = new javax.swing.JButton();
        btnBuscarp3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtCedula = new javax.swing.JTextField();
        btnBuscarmedicos = new javax.swing.JButton();
        txtEspecialidad = new javax.swing.JTextField();
        btnRecordM = new javax.swing.JButton();
        btnCantidadEsp = new javax.swing.JButton();

        jLabel10.setText("Código médico:");

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setText("Médico");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, 210, -1));

        jLabel8.setText("Cédula:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 120, -1));

        txtCodH.setBackground(new java.awt.Color(242, 242, 242));
        txtCodH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodHActionPerformed(evt);
            }
        });
        jPanel1.add(txtCodH, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 210, -1));

        btnModificarm.setBackground(new java.awt.Color(242, 242, 242));
        btnModificarm.setText("Modificar Médico");
        btnModificarm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarmActionPerformed(evt);
            }
        });
        jPanel1.add(btnModificarm, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 480, 160, -1));

        jLabel9.setText("Nombres:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 120, -1));

        txtNombres.setBackground(new java.awt.Color(242, 242, 242));
        txtNombres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombresActionPerformed(evt);
            }
        });
        jPanel1.add(txtNombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 210, -1));

        jLabel11.setText("Apellidos:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 120, -1));

        txtApellidos.setBackground(new java.awt.Color(242, 242, 242));
        txtApellidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidosActionPerformed(evt);
            }
        });
        jPanel1.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 210, -1));

        jLabel13.setText("Especialidad");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 120, -1));

        txtCodDep.setBackground(new java.awt.Color(242, 242, 242));
        txtCodDep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodDepActionPerformed(evt);
            }
        });
        jPanel1.add(txtCodDep, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 260, 210, -1));

        jLabel14.setText("Código Departamento");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 130, -1));
        jPanel1.add(lblResultado, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));
        jPanel1.add(lblPaciente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 110, 80));

        btnRegresar.setBackground(new java.awt.Color(242, 242, 242));
        btnRegresar.setText("Regresar al Menú");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 520, 160, -1));

        datos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(datos);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 20, 780, -1));

        btnAddm1.setBackground(new java.awt.Color(242, 242, 242));
        btnAddm1.setText("Agregar Médico");
        btnAddm1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddm1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnAddm1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 480, 160, -1));

        btnElminarm.setBackground(new java.awt.Color(242, 242, 242));
        btnElminarm.setText("Eliminar Médico");
        btnElminarm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnElminarmActionPerformed(evt);
            }
        });
        jPanel1.add(btnElminarm, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 480, 160, -1));

        btnBuscarm2.setBackground(new java.awt.Color(242, 242, 242));
        btnBuscarm2.setText("Consultar Médico");
        btnBuscarm2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarm2ActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscarm2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 480, 160, -1));

        btnBuscarp3.setBackground(new java.awt.Color(242, 242, 242));
        btnBuscarp3.setText("Consultar Paciente");
        btnBuscarp3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarp3ActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscarp3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 480, 160, -1));

        jLabel2.setText("Código Hospital:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 100, -1));

        txtCedula.setBackground(new java.awt.Color(242, 242, 242));
        txtCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCedulaActionPerformed(evt);
            }
        });
        jPanel1.add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 210, -1));

        btnBuscarmedicos.setBackground(new java.awt.Color(242, 242, 242));
        btnBuscarmedicos.setText("Consultar todos los médicos");
        btnBuscarmedicos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarmedicosActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscarmedicos, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 480, 190, -1));

        txtEspecialidad.setBackground(new java.awt.Color(242, 242, 242));
        txtEspecialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEspecialidadActionPerformed(evt);
            }
        });
        jPanel1.add(txtEspecialidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 210, -1));

        btnRecordM.setBackground(new java.awt.Color(242, 242, 242));
        btnRecordM.setText("Record Medico");
        btnRecordM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecordMActionPerformed(evt);
            }
        });
        jPanel1.add(btnRecordM, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 480, 190, -1));

        btnCantidadEsp.setBackground(new java.awt.Color(242, 242, 242));
        btnCantidadEsp.setText("Cantidad Especialistas");
        btnCantidadEsp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCantidadEspActionPerformed(evt);
            }
        });
        jPanel1.add(btnCantidadEsp, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 190, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 559, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtCodHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodHActionPerformed

    private void txtNombresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombresActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombresActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void txtApellidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidosActionPerformed

    private void txtCodDepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodDepActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodDepActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
       GUIMain menu = new GUIMain();
       menu.setVisible(true);
       this.setVisible(false);
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnModificarmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarmActionPerformed
        String cedula=txtCedula.getText();
        String nombre=txtNombres.getText();
        String apellido=txtApellidos.getText();
        String especialidad=txtEspecialidad.getText();
        String codD=txtCodDep.getText();
        String codH=txtCodH.getText();
        
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        
        //arreglos de parametros a pasar al metodo de operaciones
        
        //arreglos de parametros a pasar al metodo de operaciones
        String valuesMedico[][] = new String[3][4];
        String valuesPersona[][] = new String[3][4];
        String clave[] = new String[4];
        String tablaPersona = "persona";
        String tablaMedico = "medico";
        
        //Valores para el paciente
        valuesPersona[0][0] = cedula;
        valuesPersona[0][1] = nombre;
        valuesPersona[0][2] = apellido;
        valuesPersona[0][3] = codH;
        //Nombres de columnas 
        valuesPersona[1][0] = "cedula";
        valuesPersona[1][1] = "nombres";
        valuesPersona[1][2] = "apellidos";
        valuesPersona[1][3] = "cod_hospital";
        //valores del tipo de datos 
        valuesPersona[2][0] = "String";
        valuesPersona[2][1] = "String";
        valuesPersona[2][2] = "String";
        valuesPersona[2][3] = "String";
        
        //Valores para el paciente
        valuesMedico[0][0] = cedula;
        valuesMedico[0][1] = especialidad;
        valuesMedico[0][2] = codH;
        valuesMedico[0][3] = codD;
        //Nombres de columnas 
        valuesMedico[1][0] = "cedula";
        valuesMedico[1][1] = "especialidad";
        valuesMedico[1][2] = "cod_hospital";
        valuesMedico[1][3] = "cod_departamento"; 
        //valores del tipo de datos 
        valuesMedico[2][0] = "String";
        valuesMedico[2][1] = "String";
        valuesMedico[2][2] = "String";
        valuesMedico[2][3] = "Integer";
       //arreglo para la clave y parametro
        clave[0]=cedula;
        clave[1]="cedula";
        clave[2]="String";
        op.Update(conectar, tablaPersona, valuesPersona,clave);
        op.Update(conectar, tablaMedico, valuesMedico,clave);
    }//GEN-LAST:event_btnModificarmActionPerformed

    private void btnAddm1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddm1ActionPerformed
        String cedula=txtCedula.getText();
        String nombre=txtNombres.getText();
        String apellido=txtApellidos.getText();
        String especialidad=txtEspecialidad.getText();
        String codD=txtCodDep.getText();
        String codH=txtCodH.getText();
        
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        
        //arreglos de parametros a pasar al metodo de operaciones
        
        //arreglos de parametros a pasar al metodo de operaciones
        String valuesMedico[][] = new String[3][4];
        String valuesPersona[][] = new String[3][4];
        String clave[] = new String[4];
        String tablaPersona = "persona";
        String tablaMedico = "medico";
        
        //Valores para el paciente
        valuesPersona[0][0] = cedula;
        valuesPersona[0][1] = nombre;
        valuesPersona[0][2] = apellido;
        valuesPersona[0][3] = codH;
        //Nombres de columnas 
        valuesPersona[1][0] = "cedula";
        valuesPersona[1][1] = "nombres";
        valuesPersona[1][2] = "apellidos";
        valuesPersona[1][3] = "cod_hospital";
        //valores del tipo de datos 
        valuesPersona[2][0] = "String";
        valuesPersona[2][1] = "String";
        valuesPersona[2][2] = "String";
        valuesPersona[2][3] = "String";
        
        //Valores para el paciente
        valuesMedico[0][0] = cedula;
        valuesMedico[0][1] = especialidad;
        valuesMedico[0][2] = codH;
        valuesMedico[0][3] = codD;
        //Nombres de columnas 
        valuesMedico[1][0] = "cedula";
        valuesMedico[1][1] = "especialidad";
        valuesMedico[1][2] = "cod_hospital";
        valuesMedico[1][3] = "cod_departamento"; 
        //valores del tipo de datos 
        valuesMedico[2][0] = "String";
        valuesMedico[2][1] = "String";
        valuesMedico[2][2] = "String";
        valuesMedico[2][3] = "Integer";
       //arreglo para la clave y parametro
        clave[0]=cedula;
        clave[1]="cedula";
        clave[2]="String";
        op.Create(conectar, tablaPersona, valuesPersona);
        op.Create(conectar, tablaMedico, valuesMedico);
        try {
            conectar.close();
        } catch (SQLException ex) {
            Logger.getLogger(GUIMedico.class.getName()).log(Level.SEVERE, null, ex);
        }
   
        limpiar();
    }//GEN-LAST:event_btnAddm1ActionPerformed

    private void btnElminarmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnElminarmActionPerformed
        String cedula=txtCedula.getText();
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String tabla2 = "paciente";
        String tabla = "medico";
        String clave[]=new String[3];
        clave[0]=txtCedula.getText();
        clave[1]="cedula";
        clave[2]="String";
        op.Delete(conectar, tabla2, clave);
        op.Delete(conectar, tabla, clave);
    }//GEN-LAST:event_btnElminarmActionPerformed

    private void btnBuscarm2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarm2ActionPerformed
        String cedula=txtCedula.getText();
        
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String tabla1 = "persona";
        String tabla2 = "medico";
        String[][] columnas = new String[6][2];
        columnas[0][0] = "cedula"; columnas[0][1] = "persona";
        columnas[1][0] = "nombres"; columnas[1][1] = "persona";
        columnas[2][0] = "apellidos"; columnas[2][1] = "persona";
        columnas[3][0] = "especialidad"; columnas[3][1] = "objeto";
        columnas[4][0] = "cod_departamento"; columnas[4][1] = "objeto";
        columnas[5][0] = "cod_hospital"; columnas[5][1] = "objeto";
        String condicion = columnas[0][0]; 
        
        //datosModel = op.Read(conectar, tabla);
        datosModel  = op.ReadTwoTablesWhere(conectar, tabla1, tabla2, columnas, condicion,cedula);
        this.datos.setModel(datosModel);
            try {
                conectar.close();
            } catch (SQLException ex) {
                Logger.getLogger(GUIMedico.class.getName()).log(Level.SEVERE, null, ex);
            }
            
    }//GEN-LAST:event_btnBuscarm2ActionPerformed

    private void btnBuscarp3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarp3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBuscarp3ActionPerformed

    private void txtCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCedulaActionPerformed

    private void btnBuscarmedicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarmedicosActionPerformed
        String cedula=txtCedula.getText();
        
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String tabla1 = "persona";
        String tabla2 = "medico";
        String[][] columnas = new String[6][2];
        columnas[0][0] = "cedula"; columnas[0][1] = "persona";
        columnas[1][0] = "nombres"; columnas[1][1] = "persona";
        columnas[2][0] = "apellidos"; columnas[2][1] = "persona";
        columnas[3][0] = "especialidad"; columnas[3][1] = "objeto";
        columnas[4][0] = "cod_departamento"; columnas[4][1] = "objeto";
        columnas[5][0] = "cod_hospital"; columnas[5][1] = "objeto";
        String condicion = columnas[0][0]; 
        String []columns = new String[2]; 
        columns[0]= "Medico";
        columns[1]= "Pacientes atendidos";
        //datosModel = op.Read(conectar, tabla);
        datosModel  = op.ReadTwoTables(conectar, tabla1, tabla2, columnas, condicion);
        this.datos.setModel(datosModel);
        //op.ReadProcedure(conectar, "totalPacienteAtendidos", columns);
        
        try {
            conectar.close();
        } catch (SQLException ex) {
            Logger.getLogger(GUIMedico.class.getName()).log(Level.SEVERE, null, ex);
        }
                             

    }//GEN-LAST:event_btnBuscarmedicosActionPerformed

    private void txtEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEspecialidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEspecialidadActionPerformed

    private void btnRecordMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecordMActionPerformed
        // TODO add your handling code here:
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String []columns = new String[2]; 
        columns[0]= "Medico";
        columns[1]= "Pacientes atendidos";
        datosModel = op.executeProcedure(conectar, "totalPacienteAtendidos",columns);
        this.datos.setModel(datosModel);
        
        try {
            conectar.close();
        } catch (SQLException ex) {
            Logger.getLogger(GUIMedico.class.getName()).log(Level.SEVERE, null, ex);
        }
                             
    }//GEN-LAST:event_btnRecordMActionPerformed

    private void btnCantidadEspActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCantidadEspActionPerformed
        // TODO add your handling code here:
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String []columns = new String[2]; 
        columns[0]= "Especialidad";
        columns[1]= "Cantidad Especialistas";
        datosModel = op.executeProcedure(conectar, "totalEspecialidades",columns);
        this.datos.setModel(datosModel);
        
        try {
            conectar.close();
        } catch (SQLException ex) {
            Logger.getLogger(GUIMedico.class.getName()).log(Level.SEVERE, null, ex);
        }
                           
    }//GEN-LAST:event_btnCantidadEspActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUIMain().setVisible(true);
            }
        });
    }
    private void imagenSet(JLabel lbl, String ruta){
        this.imagen=new ImageIcon(ruta);
        this.icono =new ImageIcon(this.imagen.getImage().getScaledInstance(lbl.getWidth(), lbl.getHeight(), Image.SCALE_DEFAULT));
        lbl.setIcon(this.icono);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddm1;
    private javax.swing.JButton btnBuscarm2;
    private javax.swing.JButton btnBuscarmedicos;
    private javax.swing.JButton btnBuscarp3;
    private javax.swing.JButton btnCantidadEsp;
    private javax.swing.JButton btnElminarm;
    private javax.swing.JButton btnModificarm;
    private javax.swing.JButton btnRecordM;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JTable datos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JLabel lblPaciente;
    private javax.swing.JLabel lblResultado;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtCodDep;
    private javax.swing.JTextField txtCodH;
    private javax.swing.JTextField txtEspecialidad;
    private javax.swing.JTextField txtNombres;
    // End of variables declaration//GEN-END:variables
}
