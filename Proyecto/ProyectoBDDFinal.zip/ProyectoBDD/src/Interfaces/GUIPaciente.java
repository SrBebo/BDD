package Interfaces;


import Conexion.Conexion;
import Conexion.Operaciones;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;



public class GUIPaciente extends javax.swing.JFrame {
    DefaultTableModel datosModel=new DefaultTableModel();
    private ImageIcon imagen;
    private Icon icono;
    public GUIPaciente() {
        initComponents();
        this.imagenSet(this.lblPaciente, "src/Icons/Paciente.jpg");
        
    }
    
    
    
    public void limpiar(){
        txtApellidos.setText("");
        txtCodH.setText("");
        txtCodMed.setText("");
        txtHC.setText("");
        txtNombres.setText("");
        txtSintomas.setText("");
        txtCedula.setText("");
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel10 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtCodH = new javax.swing.JTextField();
        btnModificarp = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txtNombres = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtApellidos = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtHC = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        lblResultado = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtSintomas = new javax.swing.JTextArea();
        jLabel15 = new javax.swing.JLabel();
        txtCodMed = new javax.swing.JTextField();
        lblPaciente = new javax.swing.JLabel();
        btnRegresar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        datos = new javax.swing.JTable();
        btnAddp1 = new javax.swing.JButton();
        btnElminarp = new javax.swing.JButton();
        btnBuscarp2 = new javax.swing.JButton();
        btnBuscarp3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txtCedula = new javax.swing.JTextField();
        btnBuscarpacientes = new javax.swing.JButton();

        jLabel10.setText("Código médico:");

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setText("Paciente");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 30, 210, -1));

        jLabel8.setText("Cédula:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 120, -1));

        txtCodH.setBackground(new java.awt.Color(242, 242, 242));
        txtCodH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodHActionPerformed(evt);
            }
        });
        jPanel1.add(txtCodH, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 130, 210, -1));

        btnModificarp.setBackground(new java.awt.Color(242, 242, 242));
        btnModificarp.setText("Modificar Paciente");
        btnModificarp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarpActionPerformed(evt);
            }
        });
        jPanel1.add(btnModificarp, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 480, 160, -1));

        jLabel9.setText("Nombres:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, 120, -1));

        txtNombres.setBackground(new java.awt.Color(242, 242, 242));
        txtNombres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombresActionPerformed(evt);
            }
        });
        jPanel1.add(txtNombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, 210, -1));

        jLabel11.setText("Apellidos:");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 120, -1));

        txtApellidos.setBackground(new java.awt.Color(242, 242, 242));
        txtApellidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidosActionPerformed(evt);
            }
        });
        jPanel1.add(txtApellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 190, 210, -1));

        jLabel13.setText("Historia Clínica:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, 120, -1));

        txtHC.setBackground(new java.awt.Color(242, 242, 242));
        txtHC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHCActionPerformed(evt);
            }
        });
        jPanel1.add(txtHC, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 230, 210, -1));

        jLabel14.setText("Síntomas:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 130, -1));
        jPanel1.add(lblResultado, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));

        jScrollPane1.setBackground(new java.awt.Color(242, 242, 242));

        txtSintomas.setBackground(new java.awt.Color(242, 242, 242));
        txtSintomas.setColumns(20);
        txtSintomas.setRows(5);
        jScrollPane1.setViewportView(txtSintomas);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 270, 260, 120));

        jLabel15.setText("Médico:");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 410, 120, -1));

        txtCodMed.setBackground(new java.awt.Color(242, 242, 242));
        txtCodMed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCodMedActionPerformed(evt);
            }
        });
        jPanel1.add(txtCodMed, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 410, 210, -1));
        jPanel1.add(lblPaciente, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 110, 80));

        btnRegresar.setBackground(new java.awt.Color(242, 242, 242));
        btnRegresar.setText("Regresar al Menú");
        btnRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresarActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 160, -1));

        datos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(datos);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 20, 780, -1));

        btnAddp1.setBackground(new java.awt.Color(242, 242, 242));
        btnAddp1.setText("Agregar Paciente");
        btnAddp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddp1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnAddp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 480, 160, -1));

        btnElminarp.setBackground(new java.awt.Color(242, 242, 242));
        btnElminarp.setText("Eliminar Paciente");
        btnElminarp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnElminarpActionPerformed(evt);
            }
        });
        jPanel1.add(btnElminarp, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 480, 160, -1));

        btnBuscarp2.setBackground(new java.awt.Color(242, 242, 242));
        btnBuscarp2.setText("Consultar Paciente");
        btnBuscarp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarp2ActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscarp2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 480, 160, -1));

        btnBuscarp3.setBackground(new java.awt.Color(242, 242, 242));
        btnBuscarp3.setText("Consultar Paciente");
        btnBuscarp3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarp3ActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscarp3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 480, 160, -1));

        jLabel2.setText("Código Hospital:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 100, -1));

        txtCedula.setBackground(new java.awt.Color(242, 242, 242));
        txtCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCedulaActionPerformed(evt);
            }
        });
        jPanel1.add(txtCedula, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 100, 210, -1));

        btnBuscarpacientes.setBackground(new java.awt.Color(242, 242, 242));
        btnBuscarpacientes.setText("Consultar todos los pacientes");
        btnBuscarpacientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarpacientesActionPerformed(evt);
            }
        });
        jPanel1.add(btnBuscarpacientes, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 480, 190, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1259, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 559, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtCodHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodHActionPerformed

    private void txtNombresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombresActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombresActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void txtApellidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidosActionPerformed

    private void txtHCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHCActionPerformed

    private void txtCodMedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCodMedActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCodMedActionPerformed

    private void btnRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresarActionPerformed
       GUIMain menu = new GUIMain();
       menu.setVisible(true);
       this.setVisible(false);
    }//GEN-LAST:event_btnRegresarActionPerformed

    private void btnModificarpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarpActionPerformed
        String cedula=txtCedula.getText();
        String nombre=txtNombres.getText();
        String apellido=txtApellidos.getText();
        String historia=txtHC.getText();
        String codMed=txtCodMed.getText();
        String sintoma=txtSintomas.getText();
        String codH=txtCodH.getText();
        
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        
        String valuesPersona[][] = new String[3][4];
        String valuesPaciente[][] = new String[3][5];
        String clave[] = new String[4];
        String tablaPersona = "persona";
        String tablaPaciente = "paciente";
        
        //Valores para el paciente
        valuesPersona[0][0] = cedula;
        valuesPersona[0][1] = nombre;
        valuesPersona[0][2] = apellido;
        valuesPersona[0][3] = codH;
        //Nombres de columnas 
        valuesPersona[1][0] = "cedula";
        valuesPersona[1][1] = "nombres";
        valuesPersona[1][2] = "apellidos";
        valuesPersona[1][3] = "cod_hospital";
        //valores del tipo de datos 
        valuesPersona[2][0] = "String";
        valuesPersona[2][1] = "String";
        valuesPersona[2][2] = "String";
        valuesPersona[2][3] = "String";
        
        //Valores para el paciente
        valuesPaciente[0][0] = cedula;
        valuesPaciente[0][1] = codH;
        valuesPaciente[0][2] = historia;
        valuesPaciente[0][3] = sintoma;
        valuesPaciente[0][4] = codMed;
        //Nombres de columnas 
        valuesPaciente[1][0] = "cedula";
        valuesPaciente[1][1] = "cod_hospital";
        valuesPaciente[1][2] = "historia_clinica";
        valuesPaciente[1][3] = "sintomas";
        valuesPaciente[1][4] = "medico"; 
        //valores del tipo de datos 
        valuesPaciente[2][0] = "String";
        valuesPaciente[2][1] = "String";
        valuesPaciente[2][2] = "String";
        valuesPaciente[2][3] = "String";
        valuesPaciente[2][4] = "String";
       //arreglo para la clave y parametro
        clave[0]=cedula;
        clave[1]="cedula";
        clave[2]="String";
        
        op.Update(conectar, tablaPersona, valuesPersona, clave);
        op.Update(conectar, tablaPaciente, valuesPaciente, clave);
        limpiar();
    }//GEN-LAST:event_btnModificarpActionPerformed

    private void btnAddp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddp1ActionPerformed
        String cedula=txtCedula.getText();
        String nombre=txtNombres.getText();
        String apellido=txtApellidos.getText();
        String historia=txtHC.getText();
        String codMed=txtCodMed.getText();
        String sintoma=txtSintomas.getText();
        String codH=txtCodH.getText();
        
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        
        //arreglos de parametros a pasar al metodo de operaciones
        
        //arreglos de parametros a pasar al metodo de operaciones
        String valuesPaciente[][] = new String[3][5];
        String valuesPersona[][] = new String[3][4];
        String clave[] = new String[4];
        String tablaPersona = "persona";
        String tablaPaciente = "paciente";
        
        //Valores para el paciente
        valuesPersona[0][0] = cedula;
        valuesPersona[0][1] = nombre;
        valuesPersona[0][2] = apellido;
        valuesPersona[0][3] = codH;
        //Nombres de columnas 
        valuesPersona[1][0] = "cedula";
        valuesPersona[1][1] = "nombres";
        valuesPersona[1][2] = "apellidos";
        valuesPersona[1][3] = "cod_hospital";
        //valores del tipo de datos 
        valuesPersona[2][0] = "String";
        valuesPersona[2][1] = "String";
        valuesPersona[2][2] = "String";
        valuesPersona[2][3] = "String";
        
        //Valores para el paciente
        valuesPaciente[0][0] = cedula;
        valuesPaciente[0][1] = codH;
        valuesPaciente[0][2] = historia;
        valuesPaciente[0][3] = sintoma;
        valuesPaciente[0][4] = codMed;
        //Nombres de columnas 
        valuesPaciente[1][0] = "cedula";
        valuesPaciente[1][1] = "cod_hospital";
        valuesPaciente[1][2] = "historia_clinica";
        valuesPaciente[1][3] = "sintomas";
        valuesPaciente[1][4] = "medico"; 
        //valores del tipo de datos 
        valuesPaciente[2][0] = "String";
        valuesPaciente[2][1] = "String";
        valuesPaciente[2][2] = "Integer";
        valuesPaciente[2][3] = "String";
        valuesPaciente[2][4] = "String";
       //arreglo para la clave y parametro
        clave[0]=cedula;
        clave[1]="cedula";
        clave[2]="String";
        op.Create(conectar, tablaPersona, valuesPersona);
        op.Create(conectar, tablaPaciente, valuesPaciente);
        try {
            conectar.close();
        } catch (SQLException ex) {
            Logger.getLogger(GUIPaciente.class.getName()).log(Level.SEVERE, null, ex);
        }
   
        limpiar();
    }//GEN-LAST:event_btnAddp1ActionPerformed

    private void btnElminarpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnElminarpActionPerformed
        String cedula=txtCedula.getText();
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String tabla2 = "paciente";
        String tabla = "persona";
        String clave[]=new String[3];
        clave[0]=txtCedula.getText();
        clave[1]="cedula";
        clave[2]="String";
        op.Delete(conectar, tabla2, clave);
        op.Delete(conectar, tabla, clave);
        limpiar();
    }//GEN-LAST:event_btnElminarpActionPerformed

    private void btnBuscarp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarp2ActionPerformed
        String cedula=txtCedula.getText();
        
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String tabla1 = "persona";
        String tabla2 = "paciente";
        String[][] columnas = new String[7][2];
        columnas[0][0] = "cedula"; columnas[0][1] = "persona";
        columnas[1][0] = "nombres"; columnas[1][1] = "persona";
        columnas[2][0] = "apellidos"; columnas[2][1] = "persona";
        columnas[3][0] = "historia_clinica"; columnas[3][1] = "objeto";
        columnas[4][0] = "sintomas"; columnas[4][1] = "objeto";
        columnas[5][0] = "medico"; columnas[5][1] = "objeto";
        columnas[6][0] = "cod_hospital"; columnas[6][1] = "objeto";
        String condicion = columnas[0][0]; 
        
        //datosModel = op.Read(conectar, tabla);
        datosModel  = op.ReadTwoTablesWhere(conectar, tabla1, tabla2, columnas, condicion,cedula);
        this.datos.setModel(datosModel);
        try {
            conectar.close();
        } catch (SQLException ex) {
            Logger.getLogger(GUIPaciente.class.getName()).log(Level.SEVERE, null, ex);
        }
        limpiar();
    }//GEN-LAST:event_btnBuscarp2ActionPerformed

    private void btnBuscarp3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarp3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBuscarp3ActionPerformed

    private void txtCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCedulaActionPerformed

    private void btnBuscarpacientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarpacientesActionPerformed
        //Conectar con la base de datos
        Connection conectar;
        Operaciones op = new Operaciones();
        GUIMain main=new GUIMain();
        conectar=main.mainConexion();
        String tabla1 = "persona";
        String tabla2 = "paciente";
        String[][] columnas = new String[7][2];
        columnas[0][0] = "cedula"; columnas[0][1] = "persona";
        columnas[1][0] = "nombres"; columnas[1][1] = "persona";
        columnas[2][0] = "apellidos"; columnas[2][1] = "persona";
        columnas[3][0] = "historia_clinica"; columnas[3][1] = "objeto";
        columnas[4][0] = "sintomas"; columnas[4][1] = "objeto";
        columnas[5][0] = "medico"; columnas[5][1] = "objeto";
        columnas[6][0] = "cod_hospital"; columnas[6][1] = "objeto";
        String condicion = columnas[0][0]; 
        
        //datosModel = op.Read(conectar, tabla);
        datosModel  = op.ReadTwoTables(conectar, tabla1, tabla2, columnas, condicion);
        this.datos.setModel(datosModel);
        try {
            conectar.close();
        } catch (SQLException ex) {
            Logger.getLogger(GUIPaciente.class.getName()).log(Level.SEVERE, null, ex);
        }
        limpiar();
    }//GEN-LAST:event_btnBuscarpacientesActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUIMain().setVisible(true);
            }
        });
    }
    private void imagenSet(JLabel lbl, String ruta){
        this.imagen=new ImageIcon(ruta);
        this.icono =new ImageIcon(this.imagen.getImage().getScaledInstance(lbl.getWidth(), lbl.getHeight(), Image.SCALE_DEFAULT));
        lbl.setIcon(this.icono);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddp1;
    private javax.swing.JButton btnBuscarp2;
    private javax.swing.JButton btnBuscarp3;
    private javax.swing.JButton btnBuscarpacientes;
    private javax.swing.JButton btnElminarp;
    private javax.swing.JButton btnModificarp;
    private javax.swing.JButton btnRegresar;
    private javax.swing.JTable datos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JLabel lblPaciente;
    private javax.swing.JLabel lblResultado;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtCedula;
    private javax.swing.JTextField txtCodH;
    private javax.swing.JTextField txtCodMed;
    private javax.swing.JTextField txtHC;
    private javax.swing.JTextField txtNombres;
    private javax.swing.JTextArea txtSintomas;
    // End of variables declaration//GEN-END:variables
}
