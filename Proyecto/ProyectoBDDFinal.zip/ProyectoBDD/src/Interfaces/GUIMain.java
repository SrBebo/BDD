package Interfaces;

import Conexion.Conexion;
import Conexion.Operaciones;
import java.awt.Image;
import java.sql.Connection;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;


public class GUIMain extends javax.swing.JFrame {
    private ImageIcon imagen;
    private Icon icono;
    public GUIMain() {
        initComponents();
        this.imagenSet(this.lblHosp, "src/Icons/hospi.jpg");
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnCadmi = new javax.swing.JButton();
        btnCpaciente1 = new javax.swing.JButton();
        btnImedico1 = new javax.swing.JButton();
        lblHosp = new javax.swing.JLabel();
        btnDepartamento = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setText("Hospital");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 0, 300, -1));

        btnCadmi.setBackground(new java.awt.Color(204, 204, 204));
        btnCadmi.setText("Administración");
        btnCadmi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadmiActionPerformed(evt);
            }
        });
        jPanel1.add(btnCadmi, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, 170, -1));

        btnCpaciente1.setBackground(new java.awt.Color(204, 204, 204));
        btnCpaciente1.setForeground(new java.awt.Color(0, 0, 0));
        btnCpaciente1.setText("Paciente");
        btnCpaciente1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCpaciente1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnCpaciente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 120, 170, -1));

        btnImedico1.setBackground(new java.awt.Color(204, 204, 204));
        btnImedico1.setText("Medico");
        btnImedico1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImedico1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnImedico1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, 170, -1));
        jPanel1.add(lblHosp, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 90, 580, 320));

        btnDepartamento.setBackground(new java.awt.Color(204, 204, 204));
        btnDepartamento.setText("Departamento");
        btnDepartamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDepartamentoActionPerformed(evt);
            }
        });
        jPanel1.add(btnDepartamento, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 330, 170, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 464, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadmiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadmiActionPerformed
        // TODO add your handling code here:
        GUIAdministrador add=new GUIAdministrador();
        add.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnCadmiActionPerformed

    private void btnCpaciente1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCpaciente1ActionPerformed
        GUIPaciente cp=new GUIPaciente();
        cp.setVisible(true);
        /*Pacientes pa=new Pacientes());
        pa.setVisible(true);*/
        this.setVisible(false);
    }//GEN-LAST:event_btnCpaciente1ActionPerformed

    private void btnImedico1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImedico1ActionPerformed
        // TODO add your handling code here:
        GUIMedico cp=new GUIMedico();
        cp.setVisible(true);
        /*Pacientes pa=new Pacientes());
        pa.setVisible(true);*/
        this.setVisible(false);
    }//GEN-LAST:event_btnImedico1ActionPerformed

    private void btnDepartamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDepartamentoActionPerformed
        // TODO add your handling code here:
        GUIDepartamento cp=new GUIDepartamento();
        cp.setVisible(true);
        /*Pacientes pa=new Pacientes());
        pa.setVisible(true);*/
        this.setVisible(false);
    }//GEN-LAST:event_btnDepartamentoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUIMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUIMain().setVisible(true);
            }
        });
    }
    Conexion con=new Conexion();   
    //Conectar con la base de datos
    Connection conectar=con.establecerConexion();
    
    public Connection mainConexion(){
        return conectar;
    }
    private void imagenSet(JLabel lbl, String ruta){
        this.imagen=new ImageIcon(ruta);
        this.icono =new ImageIcon(this.imagen.getImage().getScaledInstance(lbl.getWidth(), lbl.getHeight(), Image.SCALE_DEFAULT));
        lbl.setIcon(this.icono);
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadmi;
    private javax.swing.JButton btnCpaciente1;
    private javax.swing.JButton btnDepartamento;
    private javax.swing.JButton btnImedico1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblHosp;
    // End of variables declaration//GEN-END:variables
}
