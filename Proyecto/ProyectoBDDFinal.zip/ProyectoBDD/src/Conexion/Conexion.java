/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author brian
 */
public class Conexion {
    public Conexion(){}
    
   
    Connection conectar=null;
    
    //Datos para establecer conexion con la base de datos
    String user ="sa";
    String password ="1234";
    String nombreBase ="Hospital_Guayaquil";
    String direccionIP ="localhost";
    String puerto ="1433";
    
    public Connection establecerConexion(){
        try{
            String cadenaConexion = "jdbc:sqlserver://localhost:" + puerto + ";" + "databaseName=" + nombreBase;
            conectar = DriverManager.getConnection(cadenaConexion,user,password);
            //System.out.println("Conexión a la base de datos " + nombreBase + " exitosa");
        
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "El siguiente error ha ocurriedo: "+e.toString());
        }
        return conectar;
    }
}
