/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conexion;

import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author brian
 */
public class Operaciones {
    
    DefaultTableModel model = new DefaultTableModel();
    ArrayList<String> column = new ArrayList<String>();
    boolean consultar;
    
    //Constructor
    public Operaciones() {}

    //Operaciones CRUD
    
    //Operacion Create - Crear   (No necesita cambios)
    
    //Sin restricciones
    public int Create(Connection conectar, String tabla,String[][]value) {
        int finalValue = 0;
        
        try {
            String createStatement = "set xact_abort on begin distributed tran INSERT INTO " + tabla + "(";
           
            for (int i = 0; i < value[0].length; i++) {
                if(i==0){
                    createStatement = createStatement + value[1][i];
                }else{
                    createStatement =  createStatement + "," + value[1][i];
                }
                
            }
            
            createStatement = createStatement + ") VALUES(";
            
            for (int i = 0; i < value[0].length; i++) {
                if(i==0){
                    createStatement =  createStatement + "? ";
                }else{
                    createStatement =  createStatement + ",? ";
                }
                
            }
            
            createStatement = createStatement + ") commit transaction";
            System.out.println(createStatement);
            PreparedStatement ps = conectar.prepareStatement(createStatement);
            System.out.println(createStatement);
            for (int i = 1; i <= value[0].length; i++) {
                if(value[2][i-1].equals("String")){
                    ps.setString(i, value[0][i-1]); 
                }else{
                    ps.setInt(i, Integer.parseInt(value[0][i-1]));
                }
                
            }
            System.out.println(createStatement);
            
            
            ps.executeUpdate();

            finalValue=1;
            
            //conectar.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalValue;
    }
    
    //Operacion Leer - Read   (No necesita cambios)
    
    //Sin restricciones
    public DefaultTableModel Read(Connection con, String tabla) {
        COLUMN_NAME(con, tabla);        //Obtener los nombres de las columnas de la tabla
        int auxRegistro = 0;            
        int contRegistro = Registros(con, tabla);
        String ColumnData[] = new String[column.size()];    //Array para los datos de la columna
        String Data[][] = new String[contRegistro][column.size()];  //Array para los datos de la tabla
        try {
            
            String readStatement = "SELECT * FROM " + tabla;
            Statement statement = con.createStatement();
            ResultSet result = statement.executeQuery(readStatement);

            System.out.println("\n");
            while (result.next()) {
                for (int i = 0; i < column.size(); i++) {
                    Data[auxRegistro][i] = (String) result.getString(column.get(i));

                }
                auxRegistro++;
                System.out.println("\n");
            }

            for (int fil = 0; fil < contRegistro; fil++) {

                for (int i = 0; i < column.size(); i++) {
                    ColumnData[i] = Data[fil][i];
                }

                model.addRow(ColumnData);

            }

            result.close();
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return model;   //Retorna el modelo de la tabla
    }
    
    //ReadTwoTables(con, persona, paciente, columnas, condicion);
    
    public DefaultTableModel ReadTwoTables(Connection con, String tabla, String tabla2, String[][] values1, String values2) {
        //COLUMN_NAME2(con, tabla, tabla2);        //Obtener los nombres de las columnas de la tabla
        int auxRegistro = 0;            
        for(int i=0;i<values1.length;i++){
                model.addColumn(values1[i][0]);
                column.add(values1[i][0]);
         }
        int contRegistro = Registros(con, tabla);
        System.out.println("values " + values1.length);
        String ColumnData[] = new String[values1.length];    //Array para los datos de la columna
        String Data[][] = new String[contRegistro][values1.length];  //Array para los datos de la tabla
        System.out.println("colum " + ColumnData.toString() + " data " + Data.toString());
        try {
            
            String readStatement = "SELECT ";
            System.out.println("antes del for " + values1.length);
            for(int i=0;i<values1.length;i++){
                if(i==0){
                    if(values1[i][1].equals("persona")){
                        System.out.println("read " + readStatement);
                        readStatement = readStatement + tabla +"."+values1[i][0]; 
                    }else{
                        readStatement = readStatement + tabla2 +"."+values1[i][0]; 

                    }
                    
                }else{
                    if(values1[i][1].equals("persona")){
                        readStatement = readStatement + "," + tabla +"."+values1[i][0];
                    }else{
                        readStatement = readStatement + "," + tabla2 +"."+values1[i][0];
                    }
                    
                }
                
            }
            System.out.println("acaba for");
            readStatement = readStatement + " FROM " + tabla + ", " + tabla2 + " WHERE " + tabla +"."+ values2 + "=" + tabla2 +"."+values2;
            
            System.out.println(readStatement);
            
            //String readStatement = "SELECT * FROM " + tabla;
            Statement statement = con.createStatement();
            ResultSet result = statement.executeQuery(readStatement);
            

            System.out.println("\n");
            while (result.next()) {
                System.out.println("resul while " + result);
                for (int i = 0; i < column.size(); i++) {
                    Data[auxRegistro][i] = (String) result.getString(column.get(i));
                    System.out.println("result " + (String)result.getString(column.get(i)));
                }
                auxRegistro++;
                System.out.println("\n");
            }

            for (int fil = 0; fil < contRegistro; fil++) {

                for (int i = 0; i < values1.length; i++) {
                    ColumnData[i] = Data[fil][i];
                    System.out.println("Data " + ColumnData[i]);
                }

                model.addRow(ColumnData);

            }

            result.close();
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return model;   //Retorna el modelo de la tabla
    }
    

    //Operacion Actualizar - Update   (No necesita cambios)
    
    public int Update(Connection conectar, String tabla, String value[][], String [] clave) {
        int finalValue = 0;
       
        try {
            String createStatement = "set xact_abort on begin distributed tran  UPDATE " + tabla + " SET ";
            
            
            for (int i = 0; i < value[0].length; i++) {
                if(i==0){
                    createStatement = createStatement +value[1][i]+"=? ";
                }else{
                    createStatement =  createStatement + "," + value[1][i]+"=? ";
                }
                
            }
           
            createStatement = createStatement + "WHERE " + clave[1] + "=? commit transaction";
            
            PreparedStatement ps = conectar.prepareStatement(createStatement);
            int contador = 0;
            //System.out.println("adios inicio");
            for (int i = 1; i <= value[0].length; i++) {
                if(value[2][i-1].equals("String")){
                    ps.setString(i, value[0][i-1]); 
                }else{
                    ps.setInt(i, Integer.parseInt(value[0][i-1]));
                }
                contador++;
                //System.out.println("adios contador");
            }
            
            if(clave[2].equals("String")){
                ps.setString(contador+1, clave[0]);
            }else{
                ps.setInt(contador+1, Integer.parseInt(clave[0]));
            }
            System.out.println(createStatement);
            ps.executeUpdate();

            finalValue=1;
            
            //conectar.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalValue;
    }
    
    //Operacion Remover - Delete   (No necesita cambios)
    
    public int Delete(Connection conectar, String tabla, String [] clave) {
        int finalValue = 0;
        try {
            String createStatement = "set xact_abort on begin distributed tran  DELETE FROM " + tabla + " WHERE " + clave[1] + " =? commit transaction";
            
            PreparedStatement ps = conectar.prepareStatement(createStatement);
            

            if(clave[2].equals("String")){
                ps.setString(1, clave[0]); 
            }else{                
                ps.setInt(1, Integer.parseInt(clave[0]));
            }
            System.out.println(createStatement);
            ps.executeUpdate();

            finalValue=1;
            
            //conectar.close();
            ps.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return finalValue;
    }
    
    public DefaultTableModel ReadWhere(Connection con, String tabla, String condicion) {
        COLUMN_NAME(con, tabla);
        int auxRegistro = 0;
        int contRegistro = RegistrosCondicionados(con, tabla, condicion);
        String ColumnData[] = new String[column.size()];
        String Data[][] = new String[contRegistro][column.size()];
        try {

            String readStatement = "SELECT * FROM " + tabla + " WHERE " + condicion;
            Statement statement = con.createStatement();
            ResultSet result = statement.executeQuery(readStatement);

            System.out.println("\n");
            while (result.next()) {
                for (int i = 0; i < column.size(); i++) {
                    Data[auxRegistro][i] = (String) result.getString(column.get(i));

                }
                auxRegistro++;
                System.out.println("\n");
            }

            for (int fil = 0; fil < contRegistro; fil++) {
                for (int i = 0; i < column.size(); i++) {
                    ColumnData[i] = Data[fil][i];
                }

                model.addRow(ColumnData);

            }

            result.close();
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return model;
    }
    
    
    public DefaultTableModel ReadTwoTablesWhere(Connection con, String tabla, String tabla2, String[][] values1, String values2, String condition) {
        //COLUMN_NAME2(con, tabla, tabla2);        //Obtener los nombres de las columnas de la tabla
        int auxRegistro = 0;            
        for(int i=0;i<values1.length;i++){
                model.addColumn(values1[i][0]);
                column.add(values1[i][0]);
         }
        int contRegistro = Registros(con, tabla);
        System.out.println("values " + values1.length);
        String ColumnData[] = new String[values1.length];    //Array para los datos de la columna
        String Data[][] = new String[contRegistro][values1.length];  //Array para los datos de la tabla
        System.out.println("colum " + ColumnData.toString() + " data " + Data.toString());
        try {
            
            String readStatement = "SELECT ";
            System.out.println("antes del for " + values1.length);
            for(int i=0;i<values1.length;i++){
                if(i==0){
                    if(values1[i][1].equals("persona")){
                        System.out.println("read " + readStatement);
                        readStatement = readStatement + tabla +"."+values1[i][0]; 
                    }else{
                        readStatement = readStatement + tabla2 +"."+values1[i][0]; 

                    }
                    
                }else{
                    if(values1[i][1].equals("persona")){
                        readStatement = readStatement + "," + tabla +"."+values1[i][0];
                    }else{
                        readStatement = readStatement + "," + tabla2 +"."+values1[i][0];
                    }
                    
                }
                
            }
            System.out.println("acaba for");
            readStatement = readStatement + " FROM " + tabla + ", " + tabla2 + " WHERE " + tabla +"."+ values2 + "=" + tabla2 +"."+values2 +" and "+tabla+"."+values2+"="+"'"+condition+"'";
            //PreparedStatement ps = con.prepareStatement(readStatement);
            //ps.setString(1, condition);
            System.out.println(readStatement);
            
            //String readStatement = "SELECT * FROM " + tabla;
            Statement statement = con.createStatement();
            ResultSet result = statement.executeQuery(readStatement);
            

            System.out.println("\n");
            while (result.next()) {
                System.out.println("resul while " + result);
                for (int i = 0; i < column.size(); i++) {
                    Data[auxRegistro][i] = (String) result.getString(column.get(i));
                    System.out.println("result " + (String)result.getString(column.get(i)));
                }
                auxRegistro++;
                System.out.println("\n");
            }

            for (int fil = 0; fil < contRegistro; fil++) {

                for (int i = 0; i < values1.length; i++) {
                    ColumnData[i] = Data[fil][i];
                    System.out.println("Data " + ColumnData[i]);
                }

                model.addRow(ColumnData);

            }

            result.close();
            statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return model;   //Retorna el modelo de la tabla
    }
    
    
 
    
    
    //Obtener nombres de columna de una tabla
    public void COLUMN_NAME(Connection con, String tabla) {
        try {
            String SQL = "select COLUMN_NAME from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA = 'dbo' and TABLE_NAME ='" + tabla + "'";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                model.addColumn(rs.getString("COLUMN_NAME"));
                column.add(rs.getString("COLUMN_NAME"));
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void COLUMN_NAME2(Connection con, String tabla, String tabla2) {
        try {
            String SQL = "select COLUMN_NAME from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA = 'dbo' and TABLE_NAME ='" + tabla + "'";
            String SQL2 = "select COLUMN_NAME from INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA = 'dbo' and TABLE_NAME ='" + tabla2 + "'";
            Statement stmt = con.createStatement();
            Statement stmt2 = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            ResultSet rs2 = stmt2.executeQuery(SQL2);

            while (rs.next()) {
                model.addColumn(rs.getString("COLUMN_NAME"));
                column.add(rs.getString("COLUMN_NAME"));
            }
            
            while (rs2.next()) {
                model.addColumn(rs2.getString("COLUMN_NAME"));
                column.add(rs2.getString("COLUMN_NAME"));
            }

            rs.close();
            rs2.close();
            stmt.close();
            stmt2.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Obtener el numero de datos de una tabla
    public int Registros(Connection con, String tabla) {
        int aux = 0;
        String SQL = "";
        try {

            SQL = "SELECT count(" + column.get(0) + ") FROM " + tabla;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                aux = Integer.parseInt(rs.getString(""));
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return aux;
    }

    //Obtener el numero de datos de una tabla con condiciones
    public int RegistrosCondicionados(Connection con, String tabla, String condicion) {
        int aux = 0;
        String SQL = "";
        try {

            SQL = "SELECT count(" + column.get(0) + ") FROM " + tabla + " WHERE " + condicion;

            //String SQL = "SELECT count(idsucursal) FROM Producto";
            //String SQL = "SELECT count(idsucursal) FROM Producto";
            //String SQL = "SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'Producto'";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            //System.out.println(rs.getString(' '));
            //aux = Integer.parseInt(rs.getString(""));
            while (rs.next()) {
                //System.out.println(rs.getString(""));
                aux = Integer.parseInt(rs.getString(""));
                //System.out.println(rs.getString("idsucursal") + ", " + rs.getString("idproveedor"));
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        //System.out.println(aux*);
        return aux;
    }


    public DefaultTableModel executeProcedure(Connection con, String procedure,String[] columna) {
        String rest = "";
        ArrayList<String>columna1=new ArrayList<String>();
        ArrayList<String>columna2=new ArrayList<String>();
        ArrayList<Object>dataVector=new ArrayList<Object>();
        
        try {
            String SQL = "exec " + procedure;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                String data[]=new String[2];
                columna1.add((String) rs.getString(columna[0]));
                data[0]=(String) rs.getString(columna[0]);
                //System.out.println("Medico = "+data[0]);
                //System.out.println(columna1.get(0));
                columna2.add((String) rs.getString(columna[1]));
                data[1]=(String) rs.getString(columna[1]);
                //System.out.println("Paciente A = "+data[1]);
                System.out.println("\n");
                dataVector.add(data);
            }
            
            for (int i=0;i<dataVector.size();i++){
                String[] aux;
                aux = (String[]) dataVector.get(i);
                System.out.println("Aux " + aux[0]);
                System.out.println("Aux " + aux[1]);
            }
            
            model.addColumn(columna[0]);
            model.addColumn(columna[1]);
            
            for (int i=0;i<dataVector.size();i++){
                System.out.println(dataVector.get(i));
                model.addRow((Object[])dataVector.get(i));
            }
            
            rs.close();
            stmt.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
        return model;
    }

    public String executeProcedureDouble(Connection con, String procedure) {
        String rest = "";
        try {
            String SQL = "exec " + procedure;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                rest = rest + (String) rs.getString("total");
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        double total = Double.parseDouble(rest);
        rest = String.format("%.2f", total);
        rest = rest.replace(",", ".");
        return rest;
    }

    public ArrayList ProcedureListEmpl(Connection con, String procedure) {
        ArrayList<String> itexBox = new ArrayList<String>();
        String rest = "";
        try {
            String SQL = "exec " + procedure;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                rest = (String) rs.getString("id_empleado") + " | " + (String) rs.getString("nombre_empleado");
                itexBox.add(rest);
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return itexBox;
    }

    public ArrayList ProcedureListProduct(Connection con, String procedure) {
        ArrayList<String> itexBox = new ArrayList<String>();
        String rest = "";
        try {
            String SQL = "exec " + procedure;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                rest = (String) rs.getString("id_producto") + " | " + (String) rs.getString("nombre_producto") + "\t| " + (String) rs.getString("stock");
                itexBox.add(rest);
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return itexBox;
    }

    public ArrayList ProcedureListCliente(Connection con, String procedure) {
        ArrayList<String> itexBox = new ArrayList<String>();
        String rest = "";
        try {
            String SQL = "exec " + procedure;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                rest = (String) rs.getString("cedula") + " | " + (String) rs.getString("nombre");
                itexBox.add(rest);
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        return itexBox;
    }

    public boolean executeProcedureBoolean(Connection con, String procedure) {
        String rest = "";
        try {
            String SQL = "exec " + procedure;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                rest = rest + (String) rs.getString("total");
            }
            rs.close();
            stmt.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        boolean bool;
        if (rest.equals("1")) {
            bool = true;
        } else {
            bool = false;
        }
        return bool;
    }

    public String executeProcedureIdSuc(Connection con, String procedure) {
        String rest = "";
        try {
            String SQL = "exec " + procedure;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                rest = rest + (String) rs.getString("total");
            }
            rs.close();
            stmt.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return rest;
    }

    public boolean isConsultar() {
        return consultar;
    }

    public void setConsultar(boolean consultar) {
        this.consultar = consultar;
    }

    public DefaultTableModel ejecutarConsultaExterno(Connection con, String tabla) {
        COLUMN_NAMEExterno(con, tabla);
        int auxRegistro = 0;
        int contRegistro = RegistrosExterno(con, tabla);
        String ColumnData[] = new String[column.size()];
        String Data[][] = new String[contRegistro][column.size()];
        try {

            String SQL = "SELECT * FROM [LENOVO].Sucursal_03.dbo." + tabla;
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            System.out.println("\n");
            while (rs.next()) {
                for (int i = 0; i < column.size(); i++) {
                    Data[auxRegistro][i] = (String) rs.getString(column.get(i));

                }
                auxRegistro++;
                System.out.println("\n");
            }

            for (int fil = 0; fil < contRegistro; fil++) {

                for (int i = 0; i < column.size(); i++) {

                    //System.out.print(Data[fil][i] + " ");//Columna
                    ColumnData[i] = Data[fil][i];

                }

                model.addRow(ColumnData);

            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return model;
    }

    public void COLUMN_NAMEExterno(Connection con, String tabla) {
        try {
            String SQL = "select COLUMN_NAME from [LENOVO].Sucursal_03.INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA  = 'dbo' and TABLE_NAME ='" + tabla + "'";
            //String SQL = "SELECT count(idsucursal) FROM Producto";
            //String SQL = "SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'Producto'";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                //System.out.println(rs.getString("COLUMN_NAME"));
                model.addColumn(rs.getString("COLUMN_NAME"));
                column.add(rs.getString("COLUMN_NAME"));
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int RegistrosExterno(Connection con, String tabla) {
        int aux = 0;
        String SQL = "";
        try {

            SQL = "SELECT count(" + column.get(0) + ") FROM [LENOVO].Sucursal_03.dbo." + tabla;

            //String SQL = "SELECT count(idsucursal) FROM Producto";
            //String SQL = "SELECT count(idsucursal) FROM Producto";
            //String SQL = "SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'Producto'";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(SQL);
            //System.out.println(rs.getString(' '));
            //aux = Integer.parseInt(rs.getString(""));
            while (rs.next()) {
                //System.out.println(rs.getString(""));
                aux = Integer.parseInt(rs.getString(""));
                //System.out.println(rs.getString("idsucursal") + ", " + rs.getString("idproveedor"));
            }

            rs.close();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        //System.out.println(aux*);
        return aux;
    }
    public DefaultTableModel ReadProcedure(Connection con, String nombreExec ,String[] values1) {
        
        ArrayList<String> data = new ArrayList<String>();            
        for(int i=0;i<values1.length;i++){
                model.addColumn(values1[i]);
                column.add(values1[i]);
         }
        
        String procedureStatement = "exec "+nombreExec;
        System.out.println(procedureStatement);
        Statement statement;
        
        try {
            statement = con.createStatement();
            
            ResultSet result = statement.executeQuery(procedureStatement);
            
            System.out.println("\n");
            while (result.next()) {
                System.out.println("result " + (String)result.getString(column.get(0)));
                
                System.out.println("\n");
            }
            
            result.close();
            statement.close();
            
        } catch (SQLException ex) {
            System.out.println("Error");
        }
        
        
        return model;
    }
}
