/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Conexion;

import Interfaces.GUIMain;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author brian
 */
public class Main {
 
    
    
    
    public static void main(String[] args) throws ClassNotFoundException {
        //Crear la instancia para la conexion
         /*Conexion con=new Conexion();
        
        //Conectar con la base de datos
        Connection conectar=con.establecerConexion();
        Operaciones op = new Operaciones();*/
        /*
        String tabla = "persona_002";
        String values[] = new String[4];
        String col[] = new String[4];
        String type[] = new String[4];
        
        values[0] = "1783";
        values[1] = "MEla";
        values[2] = "Pelas";
        values[3] = "002";
        
        col[0] = "cedula";
        col[1] = "nombres";
        col[2] = "apellidos";
        col[3] = "cod_hospital";
        
        type[0] = "String";
        type[1] = "String";
        type[2] = "String";
        type[3] = "String";
        String clave[] = new String[3];
        clave[0]="1783";
        clave[1] = "cedula";
        clave[2] = "String";
        op.Delete(conectar, tabla, clave);*/
        
        //op.Create(conectar, tabla, values, col, type);
    }    
    
}
